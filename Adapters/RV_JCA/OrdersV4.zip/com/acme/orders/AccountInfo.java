package com.acme.orders;

/**
 * Information in an account.
 */
public class AccountInfo {
    public int id;
    public String name;
    public String otherInfo;
}

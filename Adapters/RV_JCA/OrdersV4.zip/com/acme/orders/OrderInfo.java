package com.acme.orders;

/**
 * Information in an order.
 */
public class OrderInfo {
    public int id;
    public int acctId;
    public String orderItem;
    public String otherInfo;
}
